package cafeteria.external

class KakaoMessage {
  var phoneNumber :String = null
  var message :String = null
}